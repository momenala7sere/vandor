package com.sixamtech.sixvalley.seller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
